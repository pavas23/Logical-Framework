var indexSectionsWithContent =
{
  0: "bhilmnpst",
  1: "blns",
  2: "himpt"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Pages"
};

