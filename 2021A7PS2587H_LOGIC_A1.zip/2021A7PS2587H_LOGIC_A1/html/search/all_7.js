var searchData=
[
  ['stack_0',['Stack',['../class_stack.html',1,'']]]
];
