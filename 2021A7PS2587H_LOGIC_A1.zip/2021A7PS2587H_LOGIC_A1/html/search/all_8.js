var searchData=
[
  ['truthvalueofpropositionallogic_0',['TruthValueOfPropositionalLogic',['../md__task5.html',1,'']]]
];
